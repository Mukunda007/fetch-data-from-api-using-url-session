//
//  ViewController.swift
//  phpApiFetchData
//
//  Created by Mukunda Pote on 05/02/21.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tableview: UITableView!
    
     struct Jasonstruct: Codable {
         let name: String
         let capital: String
       
    }
var arraydata = [Jasonstruct]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        getdata()
    }
    func getdata(){
        guard let url = URL(string: "https://restcountries.eu/rest/v2/all")
        else{
            return
        }
        URLSession.shared.dataTask(with: url) { (data, reponse, error) in
            DispatchQueue.main.async {
                do{ if error == nil {
                    self.arraydata = try JSONDecoder().decode([Jasonstruct].self, from: data!)}
                    for mainarray in self.arraydata{
                        print(mainarray.name,":",mainarray.capital)
                        
                        DispatchQueue.main.async {
                            self.tableview.reloadData()
                        }
                        
                    }
                }catch{
                    print("There is error in jason data fetching")
                }
            }
           
            
        }.resume()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arraydata.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : TableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        
        cell.lb1.text = " Name :\(arraydata[indexPath.row].name)"
        cell.lbl2.text = "Capital : \(arraydata[indexPath.row].capital)"
        return cell
    }
       
}

// Use codable for jason struct
// prepare status for each poin in jason response
